package com.itheima.videoplayerlist.bean;

/**
 * Created by Apple on 2016/10/13.
 */
public class VideoPlayerItemInfo {
    public int id;
    public String url;
    //...

    public VideoPlayerItemInfo(int id, String url) {
        this.id = id;
        this.url = url;
    }

}
